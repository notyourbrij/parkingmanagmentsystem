const ParkingTable=require("../model/parkingdash")


exports.parkingdashboard=async(req,res)=>{

    const loginname=req.session.loginname
    const record=await ParkingTable.find().sort({status: -1})
   const total=await ParkingTable.countDocuments()
   const park=await ParkingTable.countDocuments({status:"Parked"})
   const out=await ParkingTable.countDocuments({status:"Out"})
   
    res.render("./parkingdashboard.ejs",{loginname,record,total,park,out})

   
}


exports.addvehiclentry=(req,res)=>{

    const loginname=req.session.loginname
    res.render("./addentry.ejs",{loginname,message:""})
}

exports.checkvehiclentry=(req,res)=>{

    const loginname=req.session.loginname
    const {vhno,vtype}=req.body

    const record=new ParkingTable({vno:vhno,vtype:vtype})

    record.save()

   

    res.render("./addentry.ejs",{loginname,message:"Parked"})
}




exports.deletepark=async(req,res)=>{

    const id=req.params.id

    await ParkingTable.findByIdAndDelete(id)

    res.redirect("/parkingdashboard")

}


exports.exitvehicle=async(req,res)=>{

    const loginname=req.session.loginname
    const record= await ParkingTable.find().sort({status: -1})
    res.render("./exit.ejs",{loginname,record})
}


exports.updatestatus = async (req, res) => {
    const vout = new Date()
    const id = req.params.id

    
    const record = await ParkingTable.findById(id)
    
    const totaltime = (vout - record.vin) / (1000 * 60 * 60)

    

      
        let amount

        
        switch (record.vtype) {
            case "2w":
                amount = totaltime * 30 // 30 currency units per hour for 2-wheeler
                break
            case "3w":
                amount = totaltime * 40 // 40 currency units per hour for 3-wheeler
                break
            case "4w":
                amount = totaltime * 50 // 50 currency units per hour for 4-wheeler
                break
            case "lw":
                amount = totaltime * 60 // 60 currency units per hour for light-weight vehicle
                break
            case "hw":
                amount = totaltime * 70 // 70 currency units per hour for heavy-weight vehicle
                break
            case "others":
                amount = totaltime * 45
                break
            default:
                amount = 25 
                break
        }

        if (amount < 30) {
            amount = 30
        }

       

        await ParkingTable.findByIdAndUpdate(id, {
            vout: vout,
            amount: Math.round(amount), 
            status: "Out"
        })

        res.redirect("/exit")
    }

    


    exports.logout=(req,res)=>{

        req.session.destroy()

        res.redirect("/")

    }

    
    exports.printbill=async(req,res)=>{

        const record=await ParkingTable.findById(req.params.id)
        res.render("./printbill.ejs",{record})
     
    }