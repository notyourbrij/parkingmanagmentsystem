const logintable=require("../model/login")


exports.loginpage=(req,res)=>{

    
    res.render("./login.ejs",{message:""})
}

exports.logincheck=async(req,res)=>{

    const {us,pass}=req.body

    const record=await logintable.findOne({username:us})

    if(record!==null){

        if(record.password==pass){

            
            req.session.loginname=us
            req.session.isAuth=true

        res.redirect("/parkingdashboard")
        }

        else{

            res.render("./login.ejs",{message:"wrong Password"})
        }
    }

    else{

        res.render("./login.ejs",{message:"wrong username"})
    }
}