const router=require("express").Router()

const LoginC=require("../controllers/logincontroller")

const ParkingC=require("../controllers/parkingcontroller")


function loginhandler(req,res,next){

    if(req.session.isAuth){

        next()
    }

    else{

        res.redirect("/")
    }
}


router.get("/", LoginC.loginpage)

router.post("/",LoginC.logincheck)

router.get("/parkingdashboard",loginhandler,ParkingC.parkingdashboard)

router.get("/add",loginhandler, ParkingC.addvehiclentry)
router.post("/add", ParkingC.checkvehiclentry)

router.get("/exit",loginhandler, ParkingC.exitvehicle)

router.get("/deletepark/:id",ParkingC.deletepark)

router.get("/updatestatus/:id", ParkingC.updatestatus)

router.get("/logout", ParkingC.logout) 

router.get("/printbill/:id", ParkingC.printbill)




module.exports=router