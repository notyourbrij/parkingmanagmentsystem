const express=require("express")

const app=express()

require("dotenv").config()

app.use(express.urlencoded({extended:false}))

const parkingrouter=require("./routers/parkingrouter")

const mongoose=require("mongoose")
const session=require("express-session")
mongoose.connect(`${process.env.DB_URL}/${process.env.DB_NAME}`)


//ref
app.use(session({

    secret: process.env.SECRET_KEY,
    resave:false,
    saveUninitialized:false
}))

app.use(parkingrouter)
app.use(express.static("public"))
app.set("view engine", "ejs")
app.listen(5000,()=>{console.log(`server running on port 5000`)})