const mongoose=require("mongoose")

const dschema=mongoose.Schema({

    vno:{type:String, required:true},
    vin:{type: Date, default: new Date()},
    vtype:{type:String, required:true},
    status:{type:String, default:"Parked",required:true},
    amount:Number,
    vout:Date

})

module.exports=mongoose.model("parkdash", dschema)